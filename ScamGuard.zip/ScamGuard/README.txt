ScamGuard (Android)
1. Install Android Studio. File > Open > select this ScamGuard folder. Let Gradle sync.
2. Plug in your phone (USB debugging on) and press Run. Or Build > Build APK(s) and install the APK.
3. Open the app, tap "Enable protection", allow SMS + notifications.
4. Test with "Check message". Real SMS are now scanned automatically.
If the permission is greyed out (Android 13+ sideloaded app): Settings > Apps > ScamGuard > three dots > "Allow restricted settings".
Edit rules in ScamDetector.kt.
