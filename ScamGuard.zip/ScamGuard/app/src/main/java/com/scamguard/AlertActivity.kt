package com.scamguard

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.*

class AlertActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val score = intent.getIntExtra("score", 0)
        val res = ScamResult(score, intent.getStringArrayListExtra("reasons") ?: arrayListOf())
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val col = if (score >= 70) Color.parseColor("#C62828") else Color.parseColor("#EF6C00")

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(40), dp(20), dp(20)) }
        root.addView(TextView(this).apply {
            text = "\u26A0 ${res.label}"; textSize = 26f; setTextColor(col); gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply { text = "Worry level: ${res.score} out of 100"; textSize = 16f; gravity = Gravity.CENTER })
        root.addView(TextView(this).apply {
            text = "\nThis message came from ${intent.getStringExtra("sender")}:\n\n\"${intent.getStringExtra("body")}\""; textSize = 15f
        })
        root.addView(TextView(this).apply {
            text = "\nHere's why it worries me:\n" + res.reasons.joinToString("\n") { "• $it" }; textSize = 15f
        })
        root.addView(TextView(this).apply {
            text = "\nWhat I'd do: take a breath, there's no rush. Don't tap the link, don't share any code, and don't call numbers from the message. " +
                "If you're worried it's real, call your bank using the number on the back of your card. " +
                "If you've already lost money or shared a code, call 1930 right away or visit cybercrime.gov.in. Acting fast really helps."
            textSize = 14f; setTextColor(Color.DKGRAY)
        })
        root.addView(Button(this).apply { text = "Got it, thanks"; setOnClickListener { finish() } })
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
