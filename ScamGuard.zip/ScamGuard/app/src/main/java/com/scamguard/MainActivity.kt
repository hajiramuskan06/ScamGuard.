package com.scamguard

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView

    private fun perms(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.POST_NOTIFICATIONS)
        else arrayOf(Manifest.permission.RECEIVE_SMS)

    private fun granted() = perms().all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(p, p * 2, p, p) }
        root.addView(TextView(this).apply { text = "ScamGuard"; textSize = 28f })
        status = TextView(this).apply { textSize = 16f; setPadding(0, p / 2, 0, p / 2) }
        root.addView(status)
        root.addView(Button(this).apply {
            text = "Turn on protection"
            setOnClickListener { requestPermissions(perms(), 1) }
        })
        root.addView(TextView(this).apply { text = "\nNot sure about a message? Paste it here:"; textSize = 16f })
        val input = EditText(this).apply {
            hint = "Paste the message"; minLines = 3
            setText("Dear customer your SBI KYC has expired. Update now http://sbi-kyc-update.xyz or account will be blocked today")
        }
        root.addView(input)
        val out = TextView(this).apply { textSize = 15f; setPadding(0, p / 2, 0, 0) }
        root.addView(Button(this).apply {
            text = "Check it for me"
            setOnClickListener {
                val res = ScamDetector.analyze("+919876543210", input.text.toString())
                out.text = "${res.label} (worry level ${res.score}/100)\n" + res.reasons.joinToString("\n") { "• $it" }
                if (res.shouldAlert) NotificationHelper.show(this@MainActivity, "Test", input.text.toString(), res)
            }
        })
        root.addView(out)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() { super.onResume(); refresh() }
    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) { super.onRequestPermissionsResult(c, p, r); refresh() }
    private fun refresh() {
        status.text = if (granted()) "\u2705 I'm watching your messages. Everything is checked on your phone and nothing is sent anywhere." else "\u274C I can't watch your messages yet. Tap the button and allow SMS and notifications so I can warn you."
    }
}
