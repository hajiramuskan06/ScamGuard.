package com.scamguard

data class ScamResult(val score: Int, val reasons: List<String>) {
    val label: String get() = when {
        score >= 70 -> "This looks like a scam"
        score >= 40 -> "Be careful with this one"
        else -> "Looks okay to me"
    }
    val shouldAlert: Boolean get() = score >= 40
}

/** On-device, rule-based detector. Swap analyze() for a TFLite model later if you train one. */
object ScamDetector {
    private class Rule(val regex: Regex, val weight: Int, val reason: String, val isOtp: Boolean = false)

    private fun r(p: String, w: Int, why: String, otp: Boolean = false) = Rule(Regex(p, RegexOption.IGNORE_CASE), w, why, otp)

    private val rules = listOf(
        r("kyc.{0,60}(update|expire|pending|suspend|block|verify)|(update|expire|pending|suspend|block|verify).{0,60}kyc", 35, "It says your KYC is expiring. Banks don't fix that through a text link."),
        r("(account|card|sim|upi|wallet|khata).{0,30}(blocked|suspended|deactivated|frozen|closed|band)", 30, "It threatens to block your account to scare you into acting fast."),
        r("(otp|cvv|pin|password).{0,40}(share|send|reply|tell|give|enter)|(share|send|reply|tell|give).{0,40}(otp|cvv|pin|password)", 35, "It asks for your OTP, PIN or CVV. No bank or company ever needs these from you.", otp = true),
        r("(you.?ve won|you have won|congratulations|lucky draw|lottery|jackpot|prize|cashback of|reward points)", 30, "It says you've won something. You can't win a contest you never entered."),
        r("(work from home|part.?time job|daily (income|salary)|earn.{0,15}\\d+.{0,12}(per day|daily))", 40, "It promises easy money for little work. Real employers don't recruit like this."),
        r("(telegram|whatsapp (us|me))", 15, "It tries to move you onto Telegram/WhatsApp, a common scammer tactic."),
        r("(electricity|power|bijli).{0,40}(disconnect|cut|tonight|kat)", 40, "It threatens to cut your electricity tonight. This is a very common trick."),
        r("(courier|parcel|package|delivery).{0,50}(held|failed|pending|customs|address|reschedule|fee)", 25, "It looks like a delivery problem notice asking for a small fee, a known trap."),
        r("(income tax|refund).{0,40}(pending|claim|credited|approve)", 25, "It promises a tax refund. The tax department never asks you to claim it by text."),
        r("(pan|aadhaar|aadhar).{0,30}(update|link|expire|suspend|block)", 25, "It says your PAN/Aadhaar needs urgent updating. That isn't done through SMS links."),
        r("(crypto|bitcoin|usdt|forex|trading|stock).{0,40}(profit|returns|guaranteed|invest|double your money)|(profit|returns|guaranteed|invest|double your money).{0,40}(crypto|bitcoin|usdt|forex|trading|stock)", 30, "It promises guaranteed profits. No real investment can guarantee that."),
        r("(pay|fine|penalty|settle|transfer).{0,40}(arrest|case|fir|jail|warrant)|(arrest|warrant|fir).{0,40}(pay|fine|penalty|transfer)", 25, "It demands money while threatening arrest. That is never how real police work."),
        r("loan.{0,40}(approved|instant).{0,60}(click|link|apply)", 25, "It offers an instant loan out of the blue with a link to click."),
        r("(police|cbi|narcotics|digital arrest|arrest warrant|customs officer)", 30, "It mentions police or arrests to frighten you. Real officers don't threaten people by SMS."),
        r("(turant|abhi|jaldi).{0,25}(click|update|verify|kare)", 25, "It rushes you to act right now, a classic pressure tactic."),
        r("(urgent|immediately|within 24 hours|expires today|last chance|act now|final notice)", 15, "It tries to rush you so you won't stop and think."),
        r("(click|tap|visit|open|verify|update|login).{0,25}(link|below|here|now)", 10, "It pushes you to tap a link.")
    )

    private val urlRegex = Regex(
        "(?:https?://|www\\.)\\S+|\\b[a-z0-9-]+(?:\\.[a-z0-9-]+)*\\.(?:com|in|xyz|top|click|icu|vip|cc|info|online|site|link|live|co|me|ly|gl|is|net|org)(?:/\\S*)?",
        RegexOption.IGNORE_CASE
    )
    private val shorteners = setOf("bit.ly", "tinyurl.com", "t.co", "cutt.ly", "rb.gy", "is.gd", "goo.gl", "shorturl.at", "tiny.cc", "rebrand.ly", "wa.me")
    private val badTlds = listOf(".xyz", ".top", ".click", ".icu", ".vip", ".cc", ".online", ".site", ".live", ".link", ".info")
    private val brands = mapOf(
        "sbi" to listOf("sbi.co.in", "onlinesbi.sbi", "sbi.bank.in"),
        "hdfc" to listOf("hdfcbank.com"), "icici" to listOf("icicibank.com"),
        "axis" to listOf("axisbank.com"), "paytm" to listOf("paytm.com"),
        "phonepe" to listOf("phonepe.com"), "amazon" to listOf("amazon.in", "amazon.com"),
        "flipkart" to listOf("flipkart.com"), "irctc" to listOf("irctc.co.in"),
        "uidai" to listOf("uidai.gov.in"), "incometax" to listOf("incometax.gov.in"),
        "jio" to listOf("jio.com"), "airtel" to listOf("airtel.in"), "kotak" to listOf("kotak.com")
    )
    private val ipHost = Regex("^\\d{1,3}(\\.\\d{1,3}){3}$")
    private val phoneSender = Regex("^\\+?\\d{10,13}$")
    private val finance = Regex("(bank|kyc|account|upi|card|credit|debit|loan)", RegexOption.IGNORE_CASE)
    private val legitOtp = Regex("(do not|don.?t|never)\\s+share", RegexOption.IGNORE_CASE)

    fun analyze(sender: String, body: String): ScamResult {
        var score = 0
        val reasons = mutableListOf<String>()
        var ruleHits = 0
        for (rule in rules) {
            if (!rule.regex.containsMatchIn(body)) continue
            if (rule.isOtp && legitOtp.containsMatchIn(body)) continue
            score += rule.weight; reasons += rule.reason; ruleHits++
        }
        val urls = urlRegex.findAll(body).map { it.value.trimEnd('.', ',', ')', '!') }.toList()
        for (u in urls) {
            val host = u.lowercase().removePrefix("https://").removePrefix("http://").removePrefix("www.")
                .substringBefore('/').substringBefore('?').substringBefore('#')
            if (host in shorteners) { score += 25; reasons += "The link is shortened ($host), so you can't see where it really goes." }
            if (badTlds.any { host.endsWith(it) }) { score += 20; reasons += "The web address ($host) ends in something scammers often use." }
            if (ipHost.matches(host)) { score += 30; reasons += "The link is just numbers, not a real website name." }
            if (host.count { it == '-' } >= 2) { score += 10; reasons += "The web address ($host) looks strange and stitched together." }
            for ((token, official) in brands) {
                if (host.contains(token) && official.none { host == it || host.endsWith(".$it") }) {
                    score += 35; reasons += "The link ($host) pretends to be ${token.uppercase()}, but the real site is ${official.first()}."; break
                }
            }
        }
        if (urls.isNotEmpty() && ruleHits > 0) { score += 10; reasons += "A link plus pressure is the most common scam combination." }
        if (phoneSender.matches(sender.replace(" ", "")) && finance.containsMatchIn(body)) {
            score += 15; reasons += "It talks about banking but comes from an ordinary mobile number, not a bank sender ID."
        }
        return ScamResult(score.coerceAtMost(100), reasons.distinct())
    }
}
