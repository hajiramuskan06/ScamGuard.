package com.scamguard

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

object NotificationHelper {
    private const val CHANNEL = "scam_alerts"

    fun show(ctx: Context, sender: String, body: String, res: ScamResult) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Scam alerts", NotificationManager.IMPORTANCE_HIGH))
        }
        val id = (System.currentTimeMillis() % Int.MAX_VALUE).toInt()
        val intent = Intent(ctx, AlertActivity::class.java).apply {
            putExtra("sender", sender); putExtra("body", body)
            putExtra("score", res.score); putStringArrayListExtra("reasons", ArrayList(res.reasons))
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pi = PendingIntent.getActivity(ctx, id, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("\u26A0 Careful! ${res.label}")
            .setContentText("From $sender. Please don't tap any links or share any codes. Tap to see why.")
            .setStyle(NotificationCompat.BigTextStyle().bigText("Take a breath. Don't tap links or share codes. Here's why I'm worried:\n\n" + res.reasons.take(3).joinToString("\n") { "• $it" }))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setContentIntent(pi).setAutoCancel(true).build()
        try { NotificationManagerCompat.from(ctx).notify(id, n) } catch (_: SecurityException) {}
    }
}
