package com.scamguard

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        // Multi-part SMS: join the parts per sender.
        msgs.groupBy { it.originatingAddress ?: "Unknown" }.forEach { (sender, parts) ->
            val body = parts.joinToString("") { it.messageBody ?: "" }
            val result = ScamDetector.analyze(sender, body)
            if (result.shouldAlert) NotificationHelper.show(context, sender, body, result)
        }
    }
}
